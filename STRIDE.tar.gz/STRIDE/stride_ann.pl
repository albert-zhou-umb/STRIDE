#!/usr/bin/perl

## Command line arguments: perl stride_ann.pl -input inputfile -output outputfile -Rifin threshold_score (optional) -RifinA threshold_score (optional) -RifinB threshold_score (optional) -Stevor threshold_score (optional) 
## Author: Albert Zhou and Zalak Shah, PI: Shannon Takala-Harrison, CVD, UMSOM

use strict;
use warnings;
no warnings 'uninitialized'; 
use Data::Dumper;
use Getopt::Long;

#command line option variables
my $rif_score;
my $rifa_score;
my $rifb_score;
my $stev_score;
my $STEVOR_SCORE;
my $RIFIN_SCORE;
my $RIFINA_SCORE;
my $RIFINB_SCORE;
my $input;
my $output;

#define command like options
GetOptions(
	'input=s' => \$input,
	'output=s' => \$output,
	'Rifin=i' => \$rif_score,
	'RifinA=i' => \$rifa_score,
	'RifinB=i' => \$rifb_score,
	'Stevor=i' => \$stev_score,
) or die "Usage: $0 [--input INPUTFILE] [--output OUTPUTFILE] [--Rifin NUMBER] [--RifinA NUMBER] [--RifinB NUMBER] [--Stevor NUMBER]\n";

#Open input and output file; dies if not specified
open (IFH, "<", $input) or die "Cannot open file $input $!\n";
open (OFH, ">", $output) or die "Cannot open file $output $!\n";

#if scores are speficied for rifins/stevors, use those scores
#if not defined, use default thresholds

if (defined $stev_score){
	$STEVOR_SCORE = $stev_score;
} else {
	$STEVOR_SCORE = 145;
}

if (defined $rif_score){
	$RIFIN_SCORE = $rif_score;
} else {
	$RIFIN_SCORE = 200
}

if (defined $rifa_score){
	$RIFINA_SCORE = $rifa_score;
} else {
	$RIFINA_SCORE = 250;
}

if (defined $rifb_score){
	$RIFINB_SCORE = $rifb_score;
} else {
	$RIFINB_SCORE = 250;
}

#Variable declarations for main

my @seq_array;
my %seen;
my @uniq_array;
my %data_hash;
my @data_array;
my $gene_seq;
my $score = 0; 
my @new_array;
my $prev_id = "0";
my $result;

# Main method: determine if each sequence is a stevor/rifin (which rifin subtype)
while (my $line  = <IFH>){
	chomp $line;
	#print "$line\n";
	@data_array = split/\t/, $line;
	if ($data_array[0] =~ /^STEVOR/){
		if ($data_array[3] >= $STEVOR_SCORE){
			$data_array[2] = "STEVOR"; 
		} elsif ($data_array[3] >= 99){
			$data_array[2] = "Likely_STEVOR";
		} elsif ($data_array[3] < 99){
			$data_array[2] = "Unlikely_STEVOR.More_Info_Needed";
		}
	} elsif ($data_array[0] =~ /^RIFIN-A/){
		if ($data_array[3] >= $RIFIN_SCORE){
			$data_array[2] = "RIFIN";
			if ($data_array[5] >= $RIFINA_SCORE){
				$data_array[2] = "RIFIN-A";
			}
		} elsif ($data_array[3] >= 100){
			$data_array[2] = "RIFIN_like.More_Info_Needed";
		} else {
			$data_array[2] = "Unlikely_RIFIN.More_Info_Needed";
		}
	} elsif ($data_array[0] =~ /^RIFIN-B/){
		if ($data_array[3] >= $RIFIN_SCORE){
                        $data_array[2] = "RIFIN";
                        if ($data_array[5] >= $RIFINB_SCORE){
                                $data_array[2] = "RIFIN-B";
                        }
                } elsif ($data_array[3] >= 100){
                        $data_array[2] = "RIFIN_like.More_Info_Needed";
                } else {
			$data_array[2] = "Unlikely_RIFIN.More_Info_Needed";
		}
	}
	#print "$data_array[0]\t$data_array[1]\t$data_array[2]\t$data_array[3]\n";
	#my ($prof, $seq, $seq_eval, $seq_score, $dom_eval, $dom_score) = split/\t/,$line;
 	push (@seq_array, $data_array[1]);
	$gene_seq = "$data_array[0]" . "_" . "$data_array[1]";
	my @data_array2 = splice @data_array, 0, 4;
	#print Dumper(\@data_array2);
	$data_hash{$gene_seq} = [ @data_array2 ];
}

@uniq_array = grep { ! $seen{$_}++ } @seq_array;

foreach my $element (0 .. $#uniq_array){
	for my $key (sort keys %data_hash){
		my ($key_gene, $key_seqid) = split(/ _/,$key);
		if ($uniq_array[$element] eq $key_seqid){
			if ($key_seqid eq $prev_id){
				if ($data_hash{$key}[3] > $score){
					$result = "$data_hash{$key}[0]" . "_" . "$data_hash{$key}[1]";
					$new_array[$element] = $result;
				}
			$score = $data_hash{$key}[3];
			$prev_id = $key_seqid;
			} else {
				$score = 0;
				if ($data_hash{$key}[3] > $score){
                                        $result = "$data_hash{$key}[0]" . "_" . "$data_hash{$key}[1]";
					$new_array[$element] = $result;                                                            
				}                 
			$score = $data_hash{$key}[3];                                                                                                                                $prev_id = $key_seqid;
			} 
		} 
	}
}

my %new_hash = map {$_ => $data_hash{$_}} @new_array;

for my $id (keys %new_hash){
	for my $i (1 .. $#{$new_hash{$id}}){
		print OFH "$new_hash{$id}[$i]\t";
	}
	print OFH "\n";
}

	
