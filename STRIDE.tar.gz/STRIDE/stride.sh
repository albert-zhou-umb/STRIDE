#/bin/bash
#Author: Albert Zhou (albert.zhou@som.umaryland.edu)
#Purpose: To automate processing of protein sequences in FASTA files and their classification as either RIFIN (and possible subtypes) or STEVOR

if [[ $1 == "-h" || $1 == "-help" ]];
then
        printf "\n"
        cat README.txt
        printf "\n"
else

####Extract file names to append to results
query=$1
file=`basename ${query}`
file2=${file%.*}
num_query="$(grep -c ">" $query)"
num_FHEYDER="$(grep -c 'FHEYDER' $query)"

####Search queries against a merged HMM profile
hmmscan --tblout ./results/${file2}.txt ./Final_Profiles/merged_rifstev.hmm ${query} > /dev/null

#####Move and sorts the raw, hmm results file into a directory for easier parsing
cd ./results
for i in ${file2}.txt
do
	grep "^#" -v $i | sort -k2 | awk '{print $1, "\t" $3, "\t" $5, "\t"  $6, "\t" $8, "\t" $9 "\t"}' > stride_raw.$i
		#Sort by sequence name (-k2).

       perl ../stride_ann.pl --input stride_raw.$i --output annotated2.$i
		#Annotates/Classifies the queries from the sorted file	

	sort -k1 annotated2.$i > annotated.$i
	rm $i annotated2.$i
done

####Reports the number of FHEYDER sequences in the queried FASTA file
printf "\n"; printf "\n"
echo "The number of sequences in your file (${file}) is: ${num_query}."
echo "The number of FHEYDER sequences present: ${num_FHEYDER}."
printf "\n"; printf "\n"

fi
exit 1
